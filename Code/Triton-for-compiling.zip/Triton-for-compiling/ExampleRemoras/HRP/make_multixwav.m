% make_multixwav.m
%
% script to run write_hrp2xwavs over many hrp files to make xwavs
%
% Under development

disp('make_multixwav.m is Under Development !')