function hello_pick
%
% display "Hello World" in the Message Window disp_msg
% text area
    disp_msg('Hello World');
    
