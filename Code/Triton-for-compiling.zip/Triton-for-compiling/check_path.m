function check_path
    %CHECK_PATH  Configure directory paths for Triton in MATLAB and deployed modes
    global PARAMS

    % Determine the Triton root directory
    %if isdeployed
        % In deployed mode, the EXE runs from its folder
        rootDir = pwd;
    %else
    %    % In MATLAB, locate triton.m
    %    rootDir = fileparts(which('triton'));
    %end

    % Set up the key paths
    PARAMS.path.Triton   = rootDir;
    PARAMS.path.Settings = fullfile(rootDir, 'Settings');
    PARAMS.path.Extras   = fullfile(rootDir, 'Extras');
    PARAMS.path.Remoras  = fullfile(rootDir, 'Remoras');
    PARAMS.path.tools = fullfile(rootDir, 'Tools')

    % Ensure Settings and Extras folders exist (create in MATLAB only)
    for fld = {'Settings','Extras'}
        d = PARAMS.path.(fld{1});
        if ~exist(d, 'dir')
            if ~isdeployed
                fprintf('Creating missing folder: %s\n', d);
                mkdir(d);
            else
                warning('Missing folder in deployed app: %s', d);
            end
        end
        % In MATLAB, add these to the path for development
        if ~isdeployed
            addpath(d);
        end
    end

    % Ensure the Remoras folder exists
    if ~exist(PARAMS.path.Remoras, 'dir')
        if ~isdeployed
            fprintf('Creating missing Remoras folder: %s\n', PARAMS.path.Remoras);
            mkdir(PARAMS.path.Remoras);
        else
            error('Remoras folder missing in deployed app: %s', PARAMS.path.Remoras);
        end
    end
    % In MATLAB, add all Remoras subfolders to the path
    if ~isdeployed
        addpath(genpath(PARAMS.path.Remoras));
    end

    % Read InstalledRemoras.cnf without modifying path in deployed mode
    remoraConf = fullfile(PARAMS.path.Settings, 'InstalledRemoras.cnf');
    fid = fopen(remoraConf, 'r');
    if fid ~= -1
        line = fgetl(fid);
        while ischar(line)
            rp = strtrim(line);
            if ~isempty(rp) && exist(rp, 'dir')
                % In MATLAB, add extra remora paths
                if ~isdeployed
                    addpath(genpath(rp));
                end
            end
            line = fgetl(fid);
        end
        fclose(fid);
    end
end
