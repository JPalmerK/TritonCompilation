function [savedTrainFile_TPWS, savedTestFile_TPWS] = nn_fn_balanced_input_TPWS

% load each ID file and build map of sites and bouts for each signal type

% assign train or test or not selected to each bout.

% pull TPWS info for selected events.

% save train and test files

% TODO figure out how to handle multiple training files in nnet.