Labels = {'B'};

Labels = Labels(ones(5,1));

Labels = {'B'; 'D'};

Labels([1 2 2]);