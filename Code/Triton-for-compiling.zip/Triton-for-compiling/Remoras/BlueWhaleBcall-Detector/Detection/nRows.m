function m = nRows(array)
% nRows(array) returns the number of rows in the array.

[m, n] = size(array);
