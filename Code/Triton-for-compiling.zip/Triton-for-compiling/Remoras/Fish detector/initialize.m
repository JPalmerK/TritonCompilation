global REMORA HANDLES

% Initialization script for the fish detector:

REMORA.piDetect.menu = uimenu(HANDLES.remmenu,'Label','&Fish Detector',...
    'Callback','pi_pulldown(''full_detector'')');


