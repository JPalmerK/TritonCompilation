function ct_cc_save_indiv_clust_files



