function CB_params = ct_init_cluster_bins_settings

cluster_bins_settings_default
CB_params = p;

