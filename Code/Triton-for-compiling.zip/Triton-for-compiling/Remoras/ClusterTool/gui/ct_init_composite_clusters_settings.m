function CC_params = ct_init_composite_clusters_settings

composite_clusters_settings_default;
CC_params = s;

