function ct_cc_remove_recluster(varargin)

% Show a grid of checkboxes, and ask which clusters to remove.
ct_cc_remove_clusters

% store times of bins to remove to a data file

% Return to composite clusters interface, check "remove bins from prior
% clusters", request path to removal file.

% When saving new clusters, would be good to have a different name and keep
% record of which bins were excluded.


