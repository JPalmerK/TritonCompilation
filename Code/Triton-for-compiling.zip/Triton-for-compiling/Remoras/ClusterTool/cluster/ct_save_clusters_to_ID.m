function ct_save_clusters_to_ID

% for each unique file

