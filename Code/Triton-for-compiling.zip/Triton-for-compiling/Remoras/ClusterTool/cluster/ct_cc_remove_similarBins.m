function ct_cc_remove_similarBins(varargin)

% Show a grid of checkboxes, and ask which clusters to remove.
ct_cc_remove_simBins


% Return to composite clusters interface, check "remove bins from similar
% to unwanted clusters", request path to removal file.

%would be good to have something that stores which clusters you removed,
%maybe

