function detect_params = ag_init_airgun_settings

ag_default_settings
detect_params = parm;

