:ocean: Scripps Acoustic Ecology Lab

# Airgun-Detector
Tool for detecting airguns in decimated acoustic data.
