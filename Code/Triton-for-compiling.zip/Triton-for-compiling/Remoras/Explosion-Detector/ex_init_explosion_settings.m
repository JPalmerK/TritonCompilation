function detect_params = ex_init_explosion_settings

ex_default_settings
detect_params = parm;

