function p = ec_id_settings

p.inDir = 'E:\echoTests\echoLowT\HI01-50-ICImodetest\HAWAII01_disk02';
p.outDir = 'E:\echoTests\echoLowT\HI01-50-ICImodetest\Id_files';
p.outName = 'HI01';
p.runonSub = 0;
p.inPref = 'HAWAII01*';

p.showoutName = 'on';
p.showPref = 'off';