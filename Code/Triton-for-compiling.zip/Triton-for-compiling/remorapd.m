function miscpd(action)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% remorapd.m
% callback for remora pull-down actions.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global PARAMS HANDLES DATA REMORA

RemoraConfFile = fullfile(PARAMS.path.Settings, 'InstalledRemoras.cnf');

switch action

    case 'add_remora'
        remPath = uigetdir('', 'Select the folder that contains your remora');
        if remPath == 0, return; end
        [path, folderName] = fileparts(remPath);
        original_rem = fullfile(path, folderName);
        remoraDir = fullfile(PARAMS.path.Remoras, folderName);
        if ~isequal(original_rem, remoraDir)
            copyfile(original_rem, remoraDir);
        end
        cd(PARAMS.path.Triton);
        cnf_txt = fileread(RemoraConfFile);
        if contains(cnf_txt, remoraDir)
            disp_msg(sprintf('Remora: %s already in conf file', remoraDir));
            restart_triton_dlg(); return;
        end
        fid = fopen(RemoraConfFile, 'a+');
        fprintf(fid, '%s\n', remoraDir);
        fclose(fid);
        restart_triton_dlg();

    case 'rem_remora'
        dir1 = pwd;
        cd(PARAMS.path.Remoras);
        removedRemDir = uigetdir(PARAMS.path.Remoras, 'Which do you like to remove?');
        if removedRemDir == 0, cd(dir1); return; end

        button = questdlg('Do you want to remove this remora or back it up?', 'Remove','Backup','Cancel','Remove','Backup');

        if strcmp(button, 'Remove')
            if ~isdeployed
                rmpath(genpath(removedRemDir));
                rmpath(removedRemDir);
                savepath;
            end
            [status, message] = rmdir(removedRemDir, 's');
            if status ~= 1, disp_msg(message); end

            % update conf file
            fid = fopen(RemoraConfFile, 'r');
            remlist = textscan(fid, '%s', 'Delimiter', '\n'); fclose(fid);
            remlist = remlist{1};
            fod = fopen(RemoraConfFile, 'w');
            for i = 1:numel(remlist)
                if ~strcmp(remlist{i}, removedRemDir)
                    fprintf(fod, '%s\n', remlist{i});
                else
                    disp_msg(sprintf('Removing remora from conf file: %s', removedRemDir));
                end
            end
            fclose(fod);
            restart_triton_dlg();

        elseif strcmp(button, 'Backup')
            backUp = uigetdir('', 'Where do you want the backup?');
            if backUp ~= 0
                [~, name] = fileparts(removedRemDir);
                copyfile(fullfile(removedRemDir, '*'), fullfile(backUp, name), 'f');
                if ~isdeployed
                    rmpath(removedRemDir);
                    savepath;
                end
                rmdir(removedRemDir, 's');
            else
                cd(dir1); return;
            end
            % update conf file same as above
            fid = fopen(RemoraConfFile, 'r');
            remlist = textscan(fid, '%s', 'Delimiter', '\n'); fclose(fid);
            remlist = remlist{1};
            fod = fopen(RemoraConfFile, 'w');
            for i = 1:numel(remlist)
                if ~strcmp(remlist{i}, removedRemDir)
                    fprintf(fod, '%s\n', remlist{i});
                end
            end
            fclose(fod);
            restart_triton_dlg();

        else % Cancel
            cd(dir1); return;
        end

    case 'list_remoras'
        fid = fopen(RemoraConfFile, 'r');
        remlist = textscan(fid, '%s', 'Delimiter', '\n'); fclose(fid);
        disp_msg('Installed Remoras:');
        cellfun(@(x) disp_msg(x), remlist{1});
end
end

function restart_triton_dlg()
    q_msg = ['Warning, Triton needs to be restarted after modifying Remoras.' ...
        ' Restart now?'];
    choice = questdlg(q_msg, 'Restart Triton?', 'Yes', 'No', 'Yes');
    if strcmp(choice, 'Yes')
        triton;
    else
        disp_msg('Restart Triton manually to apply changes.');
    end
end
